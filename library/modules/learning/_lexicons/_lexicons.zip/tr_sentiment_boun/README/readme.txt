in the upper folder: negative and positive words lists by the same name.
it is combined by the lists of boun & sentiturknet, with some additions.
